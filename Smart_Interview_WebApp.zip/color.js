export const PRIMARY = '#421363'
