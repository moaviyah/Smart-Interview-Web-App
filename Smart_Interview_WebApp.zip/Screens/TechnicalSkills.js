import React, { useState, useCallback } from 'react';
import { Text, View, StyleSheet, Image, Dimensions, TouchableOpacity, Platform, Alert } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { PRIMARY } from '../color';

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const TechnicalSkills = ({ navigation }) => {
    const [fileName, setFileName] = useState(null);
    const [fileType, setFileType] = useState(null);

    const handleBrowseFile = async () => {
        try {
            const result = await DocumentPicker.getDocumentAsync({
                type: '*/*',
            });
            
            if (!result.canceled) {
                setFileName(result.assets[0].name);
                setFileType(result.assets[0].mimeType);
                Alert.alert('resullt', result.assets[0].name)
            }
        } catch (err) {
            console.error(err);
        }
    };

    const handleDropFile = useCallback((event) => {
        event.preventDefault();
        const file = event.dataTransfer.files[0];
        if (file) {
            setFileName(file.name);
            setFileType(file.type);
        }
    }, []);

    const handleDragOver = useCallback((event) => {
        event.preventDefault();
    }, []);

    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.goBackContainer} onPress={() => navigation.goBack()}>
                <Image source={require('../assets/back.png')} style={styles.backIcon} />
                <Text style={styles.backTxt}>Go Back</Text>
            </TouchableOpacity>
            <View style={styles.contentCon}>
            <Text style={styles.uploadTitle}>Upload Your CV</Text>
            <Text style={styles.uploadDescription}>File upload description</Text>
            {Platform.OS === 'web' ? (
                <View
                    style={styles.uploadBox}
                    on
                    // onDrop={handleDropFile}
                    // onDragOver={handleDragOver}
                >
                    <Image source={require('../assets/add.png')} style={styles.uploadIcon} />
                    <Text style={styles.uploadText}>Drop your files here</Text>
                    <TouchableOpacity onPress={handleBrowseFile}>
                        <Text style={styles.browseText}>Browse file <Text style={{ color: PRIMARY }}>from your computer</Text></Text>
                    </TouchableOpacity>
                    {fileName && (
                        <Text style={styles.fileInfo}>
                            {fileName} 
                        </Text>
                    )}
                </View>
            ) : (
                <TouchableOpacity style={styles.uploadBox} onPress={handleBrowseFile}>
                    <Image source={require('../assets/add.png')} style={styles.uploadIcon} />
                    <Text style={styles.uploadText}>Drop your files here or</Text>
                    <Text style={styles.browseText}>Browse file <Text style={{ color: PRIMARY }}>from your computer</Text></Text>
                    {fileName && (
                        <Text style={styles.fileInfo}>
                            {fileName} ({fileType})
                        </Text>
                    )}
                </TouchableOpacity>
            )}
            
            </View>  
            <View style={styles.navigationContainer}>
                <TouchableOpacity style={styles.navButton} onPress={() => navigation.goBack()}>
                    <Text style={styles.navText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.navButton, {backgroundColor:PRIMARY}]} onPress={()=>navigation.navigate('Background')}>
                    <Text style={[styles.navText, { color: 'white' }]}>Continue</Text>
                </TouchableOpacity>
            </View> 
        </View>
    );
};

export default TechnicalSkills;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
    },
    goBackContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        width: windowWidth * 0.3
    },
    backIcon: {
        height: 30,
        width: 30,
        marginRight: 5
    },
    backTxt: {
        fontWeight: '700',
        fontSize: 16
    },
    contentCon:{
        alignItems:'center',
        width:windowWidth*0.3,
        alignSelf:'center'
    },
    uploadTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        marginVertical: 20
    },
    uploadDescription: {
        color: 'grey',
        marginBottom: 20
    },
    uploadBox: {
        borderWidth: 1,
        borderColor: 'grey',
        borderStyle: 'dashed',
        height: windowHeight * 0.3,
        width: windowWidth * 0.8,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20
    },
    uploadIcon: {
        height: 40,
        width: 40,
        marginBottom: 20
    },
    uploadText: {
        fontSize: 18,
        marginBottom: 10
    },
    browseText: {
        color: '#EAAC00'
    },
    fileInfo: {
        marginTop: 10,
        fontSize: 16,
        color: 'grey'
    },    
    navigationContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 20,
        borderTopWidth: 1,
        borderColor: '#ccc',
    },
    navButton: {
        paddingVertical: 10,
        paddingHorizontal: 20,
        backgroundColor: '#f1f1f1',
        borderRadius: 5,
    },
    navIcon: {
        height: 20,
        width: 20,
        marginHorizontal: 5,
    },
    navText: {
        fontSize: 16,
        fontWeight: 'bold',
    },
});
