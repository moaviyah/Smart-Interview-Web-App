import React, { useState, useEffect } from 'react'
import { Text, View, StyleSheet, Image, Dimensions, TouchableOpacity, TextInput } from 'react-native'
import { PRIMARY } from '../color';
const windowHeight = Dimensions.get('window').height;
const windowWIdth = Dimensions.get('window').width;

const CreateAccount = ({ navigation }) => {
    const navigateToLogin=()=>{
        navigation.navigate('Login')
    }
    return (
        <View style={styles.container}>
            <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', width: windowWIdth * 0.07 }} onPress={() => navigation.goBack()}>
                <Image source={require('../assets/back.png')} style={{ height: 50, width: 50 }} />
                <Text style={styles.backTxt}> Go Back </Text>
            </TouchableOpacity>
            <View style={styles.contentContainer}>
                <Image source={require('../assets/SignUpPic.png')} style={{ width: windowWIdth * 0.5, height: windowHeight * 0.75, marginLeft: windowWIdth * 0.05 }} />
                <View style={styles.InputContainer}>
                    <Text style={{ fontSize: 30, fontWeight: '600', fontStyle: 'italic' }}>
                        Your <Text style={{ color: '#6543BE', fontWeight: '700' }}>SUCCESS</Text> is important to us!
                    </Text>
                    <Text style={{ color: PRIMARY, fontWeight: '700', fontSize: 22, marginTop: windowHeight * 0.05 }}>
                        Create account
                    </Text>
                    <View style={{ flexDirection: 'row', marginTop: 20, paddingRight: 0 }}>
                        <View style={styles.textInputContainer}>
                            <Text style={styles.placeholder}>
                                First name
                            </Text>
                            <TextInput style={styles.input} />
                        </View>
                        <View>
                            <Text style={styles.placeholder}>
                                Last name
                            </Text>
                            <TextInput style={styles.input} />
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 20, paddingRight: 20 }}>
                        <View style={styles.textInputContainer}>
                            <Text style={styles.placeholder}>
                                Email or phone number
                            </Text>
                            <TextInput style={styles.input} />
                        </View>
                        <View style={styles.textInputContainer}>
                            <Text style={styles.placeholder}>
                                Date of birth (DD/MM/YY)
                            </Text>
                            <TextInput style={styles.input} />
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 20, paddingRight: 20 }}>
                        <View style={styles.textInputContainer}>
                            <Text style={styles.placeholder}>
                                Password
                            </Text>
                            <TextInput style={styles.input} secureTextEntry />
                        </View>
                        <View>
                            <Text style={styles.placeholder}>
                                Confirm password
                            </Text>
                            <TextInput style={styles.input} secureTextEntry />
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 20 }}>
                        <Image source={require('../assets/check-box-empty.png')} style={{ height: 24, width: 24 }} />
                        <Text style={{ marginLeft: 7, color: '#2D3748' }}>
                            Remember me
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>
                        <Image source={require('../assets/check-box-empty.png')} style={{ height: 24, width: 24 }} />
                        <Text style={{ marginLeft: 7, color: '#2D3748' }}>
                            I agree to all the <Text style={{ color: '#007AFF' }}>Terms</Text> and <Text style={{ color: '#007AFF' }}>Privacy policy</Text>
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 20 }}>
                        <TouchableOpacity style={{ backgroundColor: PRIMARY, alignItems: 'center', justifyContent: 'center', borderRadius: 5, width: windowWIdth * 0.15, paddingVertical: 10, marginRight: 30 }}>
                            <Text style={{ color: 'white', fontSize: 16, fontWeight: '700' }}>
                                Create Account
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={{ flexDirection: 'row', backgroundColor: '#EDEAEF', alignItems: 'center', justifyContent: 'center', borderRadius: 5, width: windowWIdth * 0.15, paddingVertical: 10 }}>
                            <Image source={require('../assets/google.png')} style={{ height: 24, width: 24 }} />
                            <Text style={{ fontSize: 15, fontWeight: '600', marginLeft: 5 }}>
                                Sign-in with google
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <Text style={{alignSelf:'center', marginTop:windowHeight*0.03}}>
                        Already have an account?  <TouchableOpacity style={{color:'#007AFF'}} onPress={()=>navigateToLogin()}>Log in</TouchableOpacity>
                    </Text>
                </View>
            </View>
        </View>
    )

}

export default CreateAccount
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20
    },
    backTxt: {
        fontWeight: '700',
        fontSize: 16
    },
    contentContainer: {
        flexDirection: 'row'
    },
    InputContainer: {
        paddingTop: 20
    },
    input: {
        borderWidth: 0.12,
        borderRadius: 5,
        width: windowWIdth * 0.15,
        borderColor: PRIMARY,
        height: windowHeight * 0.04,
        paddingHorizontal: 10
    },
    placeholder: {
        marginBottom: 5
    },
    textInputContainer: {
        marginRight: 30
    }
})
