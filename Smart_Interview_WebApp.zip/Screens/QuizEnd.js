import React from 'react';
import { StyleSheet, Text, View, Image, ImageBackground, TouchableOpacity, Dimensions } from 'react-native';


const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const QuizEnd = ({ navigation, route }) => {
  const { answeredQuestions } = route.params;
  console.log(answeredQuestions);

  return (
    <View style={styles.container}>
      <ImageBackground source={require('../assets/backgroundImage.png')} style={styles.backgroundImage}>
        <View style={styles.content}>
          <Image source={require('../assets/trophy.png')} style={styles.trophyImage} />
          <Text style={styles.congratulationsText}>Congratulations!</Text>
          <Text style={styles.descriptionText}>You’ve been successfully completed this session</Text>
          <View style={styles.buttonsContainer}>
            <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Results', {answeredQuestions})}>
              <Text style={styles.buttonText}>View result</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Questionaire')}>
              <Text style={styles.buttonText}>Another round</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Home')}>
              <Text style={styles.buttonText}>Home</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ImageBackground>
    </View>
  );
};

export default QuizEnd;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems:'center',
    justifyContent:'center'
  },
  backgroundImage: {
    flex:1,
    resizeMode: 'cover',
    justifyContent: 'center',
    alignItems: 'center',
    height:windowHeight*0.9,
    width:windowHeight
  },
  content: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  trophyImage: {
    width: 100, // Adjust as needed
    height: 100, // Adjust as needed
    marginBottom: 20,
  },
  congratulationsText: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  descriptionText: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
  },
  button: {
    backgroundColor: '#6200ea',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginHorizontal: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
});
