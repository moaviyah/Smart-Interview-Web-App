import React from 'react';
import { Text, View, StyleSheet, Image, Dimensions, TouchableOpacity } from 'react-native';
import { PRIMARY } from '../color';

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const GetReady = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <Text style={styles.header}>GET READY FOR YOUR SKILL ENHANCEMENT</Text>
            <View style={styles.contentContainer}>
                <Image source={require('../assets/clock.png')} style={styles.icon} />
                <Text style={styles.text}>
                    You will have <Text style={styles.highlight}>2 minutes</Text> for each question.
                </Text>
                <Image source={require('../assets/result.png')} style={styles.iconResult} />
                <Text style={styles.text}>
                    Your results will be displayed at the <Text style={styles.highlight}>end</Text> of the questionnaire.
                </Text>
            </View>
            <View style={styles.navigationContainer}>
                <TouchableOpacity style={styles.navButton} onPress={() => navigation.goBack()}>
                    <Text style={styles.navText}>BACK</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.navButton, {backgroundColor:PRIMARY}]} onPress={()=>navigation.navigate('Questionaire')}>
                    <Text style={[styles.navText, { color: 'white' }]}>NEXT</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default GetReady;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
    },
    header: {
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        backgroundColor: PRIMARY,
        color: 'white',
        padding: 15,
        marginBottom: 20,
    },
    contentContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
    },
    icon: {
        height: 100,
        width: 100,
        marginVertical: 20,
    },
    iconResult:{
        height: 60,
        width: 60,
        marginVertical: 20,
    },
    text: {
        fontSize: 18,
        textAlign: 'center',
        marginVertical: 10,
        paddingHorizontal: 20,
    },
    highlight: {
        fontWeight: 'bold',
        color: PRIMARY,
    },    
    navigationContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 20,
        borderTopWidth: 1,
        borderColor: '#ccc',
    },
    navButton: {
        paddingVertical: 10,
        paddingHorizontal: 20,
        backgroundColor: '#f1f1f1',
        borderRadius: 5,
    },
    navIcon: {
        height: 20,
        width: 20,
        marginHorizontal: 5,
    },
    navText: {
        fontSize: 16,
        fontWeight: 'bold',
    },
});
