import { StyleSheet, Text, View, Dimensions, Image, TouchableOpacity, ScrollView } from 'react-native'
import React from 'react'
import { PRIMARY } from '../color';
import LinearGradient from 'react-native-web-linear-gradient';
const windowHeight = Dimensions.get('window').height;
const windowWIdth = Dimensions.get('window').width;

const Home = ({ navigation }) => {
    const navigateToLogin = () => {
        navigation.navigate('Login')
    }
    const navigateToCreateAccount = () => {
        navigation.navigate('CreateAccount')
    }
    return (
        <View style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={true} style={styles.scrollVIewStyle}>
                <View style={styles.header}>
                    <View style={styles.logoContainer}>
                        <Image source={require('../assets/analysis.png')} style={{ height: 48, width: 48 }} />
                        <Text style={styles.logoText}>Jobs</Text>
                    </View>
                    <View style={styles.headerBtns}>
                        <View style={styles.middleHeader}>
                            <TouchableOpacity onPress={() => navigation.navigate('TechnicalSkills')} style={styles.headerTxtBtn}>
                                <Text style={{ fontWeight: '800' }}>
                                    Test your Technical Skills
                                </Text>
                            </TouchableOpacity>
                        </View>
                        <View style={styles.middleHeader}>
                            <TouchableOpacity onPress={() => navigation.navigate('InterviewPreferences')}>
                                <Text style={{ fontWeight: '800' }}>
                                    Prepare for interview
                                </Text>
                            </TouchableOpacity>
                        </View>
                        <View style={styles.middleHeader}>
                            <TouchableOpacity onPress={() => navigation.navigate('FindJobs')}>
                                <Text style={{ fontWeight: '800' }}>
                                    Find Jobs
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <View style={styles.btns}>
                        <TouchableOpacity style={styles.btn} onPress={() => navigateToLogin()}>
                            <Text style={styles.btnTxt}>
                                Login
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.btn, { backgroundColor: PRIMARY, marginLeft: 20 }]} onPress={() => navigateToCreateAccount()}>
                            <Text style={[styles.btnTxt, { color: 'white' }]}>
                                Create Account
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={styles.hero}>
                    <View style={{ width: '30%' }}>
                        <Image source={require('../assets/text.png')} style={{ height: windowHeight * 0.18, width: windowHeight * 0.5, }} />
                        <Text style={{ marginTop: 50, fontSize: 24, fontWeight: '300' }}>
                            This is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has
                            been the industry's standard dummy text
                            ever since the 1500s, when an unknown
                            printer took a galley of type and scrambled
                            it to make a type specimen book.
                        </Text>
                        <TouchableOpacity style={{ backgroundColor: PRIMARY, justifyContent: 'center', alignItems: 'center', borderRadius: 10, paddingVertical: windowHeight * 0.02, width: windowWIdth * 0.1, marginTop: windowHeight * 0.06 }}>
                            <Text style={{ fontWeight: 'bold', color: 'white' }}>
                                Get Started
                            </Text>
                        </TouchableOpacity>
                        <Image source={require('../assets/ratings.png')} style={{ width: windowWIdth * 0.15, height: windowHeight * 0.03, marginTop: windowHeight * 0.03 }} />
                    </View>

                    <View>
                        <Image source={require('../assets/heroPic.png')} style={{ height: windowHeight * 0.7, width: windowWIdth * 0.3 }} />
                    </View>
                </View>

                <View style={styles.figsContainer}>
                    <View style={[styles.singleFig, { borderLeftWidth: 0 }]}>
                        <Text style={[styles.boldText, { marginTop: 0 }]}>
                            People Productivity
                        </Text>
                        <Text style={styles.boldText}>
                            Performance
                        </Text>
                    </View>
                    <View style={styles.singleFig}>
                        <Text style={styles.notBoldText}>
                            JOBS
                        </Text>
                        <Text style={styles.boldText}>
                            +235K
                        </Text>
                    </View>
                    <View style={styles.singleFig}>
                        <Text style={styles.notBoldText}>
                            STARTUPS
                        </Text>
                        <Text style={styles.boldText}>
                            +60K
                        </Text>
                    </View>
                    <View style={[styles.singleFig, { borderRightWidth: 0 }]}>
                        <Text style={styles.notBoldText}>
                            Talent
                        </Text>
                        <Text style={styles.boldText}>
                            +678K
                        </Text>
                    </View>
                </View>

                <View style={styles.howWeWorkContainer}>
                    <Text style={styles.howWeWorkBold}>How we work</Text>
                    <Text style={styles.howWeWorkText}> is simply dummy text of the printing and {'\n'} typesetting industry. Lorem</Text>
                </View>

                <View style={styles.howWeWorkCardsContainer}>
                    <View style={styles.howWeWorkCard}>
                        <View style={styles.iconBackground}>
                            <Image source={require('../assets/icon.png')} style={styles.icon} />
                        </View>
                        <Text style={styles.howWeWorkTitle}>
                            Precise Fit
                        </Text>
                        <Text style={styles.howWeWorkDesc}>
                            is simply dummy text of the printing and {'\n'} typesetting industry. Lorem
                        </Text>
                    </View>
                    <View style={styles.howWeWorkCard}>
                        <View style={styles.iconBackground}>
                            <Image source={require('../assets/icon2.png')} style={styles.icon} />

                        </View>
                        <Text style={styles.howWeWorkTitle}>
                            Easy & Fast
                        </Text>
                        <Text style={styles.howWeWorkDesc}>
                            is simply dummy text of the printing and {'\n'} typesetting industry. Lorem
                        </Text>
                    </View>
                    <View style={styles.howWeWorkCard}>
                        <View style={styles.iconBackground}>
                            <Image source={require('../assets/icon1.png')} style={styles.icon} />
                        </View>
                        <Text style={styles.howWeWorkTitle}>
                            Assistance
                        </Text>
                        <Text style={styles.howWeWorkDesc}>
                            is simply dummy text of the printing and {'\n'} typesetting industry. Lorem
                        </Text>
                    </View>
                    <View style={styles.howWeWorkCard}>
                        <View style={styles.iconBackground}>
                            <Image source={require('../assets/reliable.png')} style={styles.icon} />
                        </View>
                        <Text style={styles.howWeWorkTitle}>
                            Reliable
                        </Text>
                        <Text style={styles.howWeWorkDesc}>
                            is simply dummy text of the printing and {'\n'} typesetting industry. Lorem
                        </Text>
                    </View>
                </View>

                <View style={styles.meetOurTeamContainer}>
                    <Text style={styles.howWeWorkBold}>Meet Talent in Our Network</Text>
                    <Text style={styles.howWeWorkText}>is simply dummy text of the printing and</Text>
                </View>

                <View style={styles.meetOurTeamCardsConainer}>
                    <View style={styles.meetOutTeamCard}>
                        <Image source={require('../assets/team1.png')} style={styles.meetOurTeamImage} />
                        <Text style={styles.teamName}>
                            Random Name
                        </Text>
                        <Text style={styles.teamDesc}>
                            simply dummy
                        </Text>
                        <View style={styles.teamRatingContainer}>
                            <Text style={styles.ratingPoint}>
                                4.0
                            </Text>
                            <Image source={require('../assets/ratingImg.png')} style={styles.ratingImg} />
                            <Text style={styles.ratingPoint}>
                                567K+ Ratings
                            </Text>
                        </View>
                    </View>
                    <View style={styles.meetOutTeamCard}>
                        <Image source={require('../assets/team2.png')} style={styles.meetOurTeamImage} />
                        <Text style={styles.teamName}>
                            Random Name
                        </Text>
                        <Text style={styles.teamDesc}>
                            simply dummy
                        </Text>
                        <View style={styles.teamRatingContainer}>
                            <Text style={styles.ratingPoint}>
                                4.0
                            </Text>
                            <Image source={require('../assets/ratingImg.png')} style={styles.ratingImg} />
                            <Text style={styles.ratingPoint}>
                                567K+ Ratings
                            </Text>
                        </View>
                    </View>
                    <View style={styles.meetOutTeamCard}>
                        <Image source={require('../assets/team3.png')} style={styles.meetOurTeamImage} />
                        <Text style={styles.teamName}>
                            Random Name
                        </Text>
                        <Text style={styles.teamDesc}>
                            simply dummy
                        </Text>
                        <View style={styles.teamRatingContainer}>
                            <Text style={styles.ratingPoint}>
                                4.0
                            </Text>
                            <Image source={require('../assets/ratingImg.png')} style={styles.ratingImg} />
                            <Text style={styles.ratingPoint}>
                                567K+ Ratings
                            </Text>
                        </View>
                    </View>
                    <View style={styles.meetOutTeamCard}>
                        <Image source={require('../assets/team4.png')} style={styles.meetOurTeamImage} />
                        <Text style={styles.teamName}>
                            Random Name
                        </Text>
                        <Text style={styles.teamDesc}>
                            simply dummy
                        </Text>
                        <View style={styles.teamRatingContainer}>
                            <Text style={styles.ratingPoint}>
                                4.0
                            </Text>
                            <Image source={require('../assets/ratingImg.png')} style={styles.ratingImg} />
                            <Text style={styles.ratingPoint}>
                                567K+ Ratings
                            </Text>
                        </View>
                    </View>
                </View>

                <View style={styles.howWeWorkContainer}>
                    <Text style={styles.howWeWorkBold}>How we work</Text>
                    <Text style={styles.howWeWorkText}> is simply dummy text of the printing and {'\n'} typesetting industry. Lorem</Text>
                </View>

                <View style={styles.howWeWork2Container}>
                    <LinearGradient style={styles.howWeWork2Card} colors={['#838586', '#202020',]}>
                        <Image source={require('../assets/icon2-1.png')} style={styles.howWeWork2Img} />
                        <Text style={styles.howWeWork2Title}>Tell Us What YOU {'\n'}Need</Text>
                        <Text style={styles.howWeWork2Desc}>
                            is simply dummy text of the printing and
                            type setting industry. is simply dummy
                            text of the printing and type setting
                            industry. is simply dummy text of the
                            printing and type setting industry. is
                            simply dummy text of the printing and
                            type setting industry. is simply dummy
                            text of the printing and type setting
                            industry. is simply dummy text of the
                            printing and type setting industry.
                        </Text>
                    </LinearGradient>
                    <LinearGradient style={styles.howWeWork2Card} colors={['#838586', '#202020',]}>
                        <Image source={require('../assets/icon2-2.png')} style={styles.howWeWork2Img} />
                        <Text style={styles.howWeWork2Title}>Tell Us What YOU {'\n'}Need</Text>
                        <Text style={styles.howWeWork2Desc}>
                            is simply dummy text of the printing and
                            type setting industry. is simply dummy
                            text of the printing and type setting
                            industry. is simply dummy text of the
                            printing and type setting industry. is
                            simply dummy text of the printing and
                            type setting industry. is simply dummy
                            text of the printing and type setting
                            industry. is simply dummy text of the
                            printing and type setting industry.
                        </Text>
                    </LinearGradient>
                    <LinearGradient style={styles.howWeWork2Card} colors={['#838586', '#202020',]}>
                        <Image source={require('../assets/icon2-3.png')} style={styles.howWeWork2Img} />
                        <Text style={styles.howWeWork2Title}>Tell Us What YOU {'\n'}Need</Text>
                        <Text style={styles.howWeWork2Desc}>
                            is simply dummy text of the printing and
                            type setting industry. is simply dummy
                            text of the printing and type setting
                            industry. is simply dummy text of the
                            printing and type setting industry. is
                            simply dummy text of the printing and
                            type setting industry. is simply dummy
                            text of the printing and type setting
                            industry. is simply dummy text of the
                            printing and type setting industry.
                        </Text>
                    </LinearGradient>
                    <LinearGradient style={styles.howWeWork2Card} colors={['#838586', '#202020',]}>
                        <Image source={require('../assets/icon2-3.png')} style={styles.howWeWork2Img} />
                        <Text style={styles.howWeWork2Title}>Tell Us What YOU {'\n'}Need</Text>
                        <Text style={styles.howWeWork2Desc}>
                            is simply dummy text of the printing and
                            type setting industry. is simply dummy
                            text of the printing and type setting
                            industry. is simply dummy text of the
                            printing and type setting industry. is
                            simply dummy text of the printing and
                            type setting industry. is simply dummy
                            text of the printing and type setting
                            industry. is simply dummy text of the
                            printing and type setting industry.
                        </Text>
                    </LinearGradient>
                </View>

                <View style={styles.trustContainer}>
                    <View style={styles.trustTextContainer}>
                        <Text style={styles.trustText}>
                            Why Leading Tech {'\n'}Companies {'\n'}Trust The Arrows.
                        </Text>
                        <TouchableOpacity style={styles.trustBtn}>
                            <Text style={styles.trustBtnTxt}>
                                Learn More
                            </Text>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.teamPicsContainer}>
                        <View style={styles.singleTeamContainer}>
                            <Image source={require('../assets/team3.png')} style={styles.trustTeamImg} />
                            <Text style={[styles.teamName, { color: PRIMARY, alignSelf: 'flex-start' }]}>
                                Random name
                            </Text>
                            <Text style={styles.teamDesc}>
                                is simply dummy text of the printing and
                                type setting industry. is simply dummy
                                text of the printing and type setting
                                industry.
                            </Text>
                        </View>
                        <View style={styles.singleTeamContainer}>
                            <Image source={require('../assets/team1.png')} style={styles.trustTeamImg} />
                            <Text style={[styles.teamName, { color: PRIMARY, alignSelf: 'flex-start' }]}>
                                Random name
                            </Text>
                            <Text style={styles.teamDesc}>
                                is simply dummy text of the printing and
                                type setting industry. is simply dummy
                                text of the printing and type setting
                                industry.
                            </Text>
                        </View>
                    </View>
                </View>

                <View style={styles.discussContainer}>
                    <Text style={styles.discussTitleTxt}>
                        LET'S DISCUSS YOUR PROJECT AND {'\n'}FIND OUT A PERFECT EMPLOYEE {'\n'}TOGETHER?
                    </Text>
                    <View style={styles.discussCard}>
                        <Image source={require('../assets/discussImage.png')} style={styles.discussImage} />
                        <View style={styles.discussTextCard}>
                            <View style={styles.discussTextContainer}>
                                <Text style={[styles.teamName, { alignSelf: 'flex-start', color: PRIMARY }]}>
                                    Random name
                                </Text>
                                <Text style={styles.teamDesc}>
                                    is simply dummy text of the printing and{'\n'}
                                    type setting industry. is simply dummy{'\n'}
                                    text of the printing and type setting{'\n'}
                                    industry.
                                </Text>
                            </View>
                            <View style={styles.discussTextContainer}>
                                <Text style={[styles.teamName, { alignSelf: 'flex-start', color: PRIMARY }]}>
                                    Random name
                                </Text>
                                <Text style={styles.teamDesc}>
                                    is simply dummy text of the printing and{'\n'}
                                    type setting industry. is simply dummy{'\n'}
                                    text of the printing and type setting{'\n'}
                                    industry.
                                </Text>
                            </View>
                            <View style={styles.discussTextContainer}>
                                <Text style={[styles.teamName, { alignSelf: 'flex-start', color: PRIMARY }]}>
                                    Random name
                                </Text>
                                <Text style={styles.teamDesc}>
                                    is simply dummy text of the printing and{'\n'}
                                    type setting industry. is simply dummy{'\n'}
                                    text of the printing and type setting{'\n'}
                                    industry.
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>

            </ScrollView>
        </View>
    )
}

export default Home

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    scrollVIewStyle: {
        paddingVertical: windowHeight * 0.03
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: windowWIdth * 0.05,
    },
    headerBtns:{
        flexDirection:'row',
        width:windowWIdth*0.3,
        
    },
    headerTxtBtn:{
        marginHorizontal:20
    },
    logoContainer: {
        flexDirection: 'row',
        alignSelf: 'center'
    },
    logoText: {
        fontWeight: 'bold',
        fontSize: 22,
        alignSelf: 'center',
        marginLeft: 15
    },
    btns: {
        flexDirection: 'row'
    },
    btn: {
        backgroundColor: 'white',
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: 'black'
    },
    btnTxt: {
        color: 'black',
        fontWeight: 'bold'
    },
    middleHeader: {
        marginHorizontal:10
    },
    hero: {
        flexDirection: 'row',
        marginTop: windowHeight * 0.05,
        justifyContent: 'space-between',
        paddingHorizontal: windowWIdth * 0.05,
    },
    figsContainer: {
        backgroundColor: 'black',
        flexDirection: 'row',
        height: windowHeight * 0.2,
        marginTop: 20,
        justifyContent: 'space-between',
    },
    boldText: {
        fontWeight: '700',
        color: 'white',
        fontSize: 24,
        marginTop: 20
    },
    singleFig: {
        alignItems: 'center',
        justifyContent: 'center',
        borderRightWidth: 0.01,
        borderLeftWidth: 0.01,
        borderColor: 'white',
        flex: 1,
        marginVertical: 25
    },
    notBoldText: {
        color: 'white',
        fontSize: 24,
    },
    howWeWorkBold: {
        fontSize: 56,
        fontWeight: '500'
    },
    howWeWorkText: {
        fontSize: 36,
        marginTop: 15,
        textAlign: 'center',
        fontWeight: '300'
    },
    howWeWorkContainer: {
        alignItems: 'center',
        justifyContent: 'space-between',
        marginVertical: 20
    },
    howWeWorkCardsContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: windowWIdth * 0.05,
    },
    howWeWorkCard: {
        borderWidth: 5,
        borderColor: '#CCC',
        padding: 20,
        borderRadius: 20,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 4,
        },
        shadowOpacity: 0.2,
        shadowRadius: 8,
        elevation: 5,
    },
    iconBackground: {
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 500,
        backgroundColor: PRIMARY,
        padding: 30
    },
    icon: {
        height: 70,
        width: 70,
        alignSelf: 'center'
    },
    howWeWorkTitle: {
        alignSelf: 'center',
        fontSize: 26,
        fontWeight: '500',
        marginVertical: 15
    },
    howWeWorkDesc: {
        textAlign: 'center',
        fontSize: 18
    },
    meetOurTeamContainer: {
        alignItems: 'center'
    },
    meetOurTeamCardsConainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: windowWIdth * 0.05,
        marginTop: 30
    },
    meetOutTeamCard: {

    },
    meetOurTeamImage: {
        height: windowHeight * 0.46,
        width: windowWIdth * 0.17
    },
    teamName: {
        alignSelf: 'center',
        fontSize: 22,
        fontWeight: '600'
    },
    teamDesc: {
        alignSelf: 'center',
        marginVertical: 10,
        fontSize: 16
    },
    teamRatingContainer: {
        flexDirection: 'row',
        alignSelf: 'center',
        alignItems: 'center'
    },
    ratingPoint: {
        fontWeight: '700',
        marginHorizontal: 5
    },
    ratingImg: {
        width: 100,
        height: 20
    },
    howWeWork2Container: {
        flexDirection: 'row',
        paddingHorizontal: windowWIdth * 0.05,
        justifyContent: 'space-between',
        marginVertical: 20,

    },
    howWeWork2Card: {
        backgroundColor: '#838586',
        width: windowWIdth * 0.2,
        borderRadius: 15,
        padding: 20
    },
    howWeWork2Img: {
        height: windowHeight * 0.1,
        width: windowHeight * 0.1,
        alignSelf: 'center'
    },
    howWeWork2Title: {
        color: 'white',
        marginVertical: 10,
        fontWeight: '700',
        fontSize: 24,
        marginTop: 30
    },
    howWeWork2Desc: {
        color: 'white',
        fontSize: 16
    },
    trustContainer: {
        flexDirection: 'row',
        paddingHorizontal: windowWIdth * 0.05,
        marginVertical: 40
    },
    trustTextContainer: {
        flex: 1
    },
    trustText: {
        fontSize: 80,
        color: PRIMARY,
        fontWeight: '600'
    },
    trustBtn: {
        backgroundColor: PRIMARY,
        paddingHorizontal: 30,
        paddingVertical: 15,
        borderRadius: 10,
        alignItems: "center",
        justifyContent: 'center',
        width: windowWIdth * 0.1,
        marginTop: 40,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 4,
        },
        shadowOpacity: 0.2,
        shadowRadius: 8,
        elevation: 5,
    },
    trustBtnTxt: {
        color: 'white',
        fontWeight: '700'
    },
    teamPicsContainer: {
        flex: 1,
        flexDirection: 'row'
    },
    singleTeamContainer: {
        flex: 1
    },
    trustTeamImg: {
        height: windowHeight * 0.6,
        width: windowHeight * 0.5
    },
    discussContainer: {
        paddingHorizontal: windowWIdth * 0.05,
    },
    discussTitleTxt: {
        fontSize: 70,
        color: PRIMARY,
        fontWeight: '500'
    },
    discussCard: {
        flexDirection: 'row',
        marginTop: 40
    },
    discussImage: {
        height: windowHeight * 0.84,
        width: windowWIdth * 0.5
    },
    discussTextContainer: {
        marginVertical: 30,
        marginHorizontal: 60
    },
})