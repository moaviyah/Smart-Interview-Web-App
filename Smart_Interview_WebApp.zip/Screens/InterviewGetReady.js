import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const InterviewGetReady = ({navigation}) => {
  return (
    <View style={styles.container}>
      <Text>InterviewGetReady</Text>
    </View>
  )
}

export default InterviewGetReady

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
    },
})