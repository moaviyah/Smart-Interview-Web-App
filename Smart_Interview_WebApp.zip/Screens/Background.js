import React, { useState } from 'react';
import { Text, View, StyleSheet, Image, Dimensions, TouchableOpacity, Picker, TouchableWithoutFeedback } from 'react-native';
import { PRIMARY } from '../color';

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const Background = ({ navigation }) => {
    const [status, setStatus] = useState('');
    const [degree, setDegree] = useState('');
    const [experience, setExperience] = useState('');
    const [rating, setRating] = useState(0);

    const getRatingText = () => {
        switch (rating) {
            case 1:
                return { label: 'Done Once', description: 'Know somethings about job interviews' };
            case 2:
                return { label: 'BEGINNER', description: 'Have a basic understanding of job interviews' };
            case 3:
                return { label: 'INTERMEDIATE', description: 'Comfortable with job interviews but need more practice' };
            case 4:
                return { label: 'ADVANCED', description: 'Confident in job interviews with a good amount of experience' };
            case 5:
                return { label: 'EXPERT', description: 'Highly skilled in job interviews with extensive experience' };
            default:
                return { label: 'CLUELESS', description: 'Know nothing about job interviews' };
        }
    };

    const renderStars = () => {
        const stars = [];
        for (let i = 1; i <= 5; i++) {
            stars.push(
                <TouchableWithoutFeedback key={i} onPress={() => setRating(i)}>
                    <Image
                        source={require('../assets/star.png')}
                        style={[
                            styles.star,
                            { tintColor: i <= rating ? '#EAAC00' : 'grey' }
                        ]}
                    />
                </TouchableWithoutFeedback>
            );
        }
        return stars;
    };

    const { label, description } = getRatingText();

    return (
        <View style={styles.container}>
             <TouchableOpacity style={styles.goBackContainer} onPress={() => navigation.goBack()}>
                <Image source={require('../assets/back.png')} style={styles.backIcon} />
                <Text style={styles.backTxt}>Go Back</Text>
            </TouchableOpacity>
            <Text style={styles.header}>TELL US ABOUT YOUR BACKGROUND</Text>
            <View style={styles.formContainer}>
                <Text style={styles.label}>EDUCATION:</Text>
                <Picker
                    selectedValue={status}
                    style={styles.picker}
                    onValueChange={(itemValue) => {
                        setStatus(itemValue);
                        if (itemValue !== 'Student') {
                            setDegree('');
                        }
                    }}
                >
                    <Picker.Item label="Select status" value="" />
                    <Picker.Item label="Student" value="Student" />
                    <Picker.Item label="Employee" value="Employee" />
                    <Picker.Item label="None of the above" value="None" />
                </Picker>

                {status === 'Student' && (
                    <Picker
                        selectedValue={degree}
                        style={styles.picker}
                        onValueChange={(itemValue) => setDegree(itemValue)}
                    >
                        <Picker.Item label="Select degree" value="" />
                        <Picker.Item label="Bachelor's" value="Bachelor's" />
                        <Picker.Item label="Master's" value="Master's" />
                        <Picker.Item label="PhD" value="PhD" />
                    </Picker>
                )}

                <Text style={styles.label}>YEARS OF PROFESSIONAL EXPERIENCE:</Text>
                <Picker
                    selectedValue={experience}
                    style={styles.picker}
                    onValueChange={(itemValue) => setExperience(itemValue)}
                >
                    <Picker.Item label="Select your experience" value="" />
                    <Picker.Item label="0-1 years" value="0-1" />
                    <Picker.Item label="1-3 years" value="1-3" />
                    <Picker.Item label="3-5 years" value="3-5" />
                    <Picker.Item label="5+ years" value="5+" />
                </Picker>

                <Text style={styles.label}>WHAT IS YOUR CURRENT LEVEL AT JOB INTERVIEWS?</Text>
                <View style={styles.starsContainer}>
                    {renderStars()}
                </View>
                <Text style={styles.ratingLabel}>{label}</Text>
                <Text style={styles.ratingDescription}>{description}</Text>
            </View>

            <View style={styles.navigationContainer}>
                <TouchableOpacity style={styles.navButton} onPress={() => navigation.goBack()}>
                    <Text style={styles.navText}>BACK</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.navButton, {backgroundColor:PRIMARY}]} onPress={()=>navigation.navigate('Preferences')}>
                    <Text style={[styles.navText, { color: 'white' }]}>NEXT</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default Background;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
    },
    goBackContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        width: windowWidth * 0.3,
        marginVertical:10
    },
    backIcon: {
        height: 30,
        width: 30,
        marginRight: 5
    },
    backTxt: {
        fontWeight: '700',
        fontSize: 16
    },
    header: {
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        backgroundColor: PRIMARY,
        color: 'white',
        padding: 15,
    },
    formContainer: {
        padding: 20,
    },
    label: {
        fontSize: 16,
        fontWeight: 'bold',
        marginVertical: 10,
    },
    picker: {
        height: 50,
        width: '100%',
        borderColor: 'gray',
        borderWidth: 1,
        borderRadius: 5,
        marginVertical: 10,
    },
    starsContainer: {
        flexDirection: 'row',
        marginVertical: 10,
    },
    star: {
        height: 40,
        width: 40,
        marginHorizontal: 5,
    },
    ratingLabel: {
        fontSize: 16,
        fontWeight: 'bold',
        marginVertical: 10,
    },
    ratingDescription: {
        color: 'gray',
        marginBottom: 20,
    },    
    navigationContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 20,
        borderTopWidth: 1,
        borderColor: '#ccc',
    },
    navButton: {
        paddingVertical: 10,
        paddingHorizontal: 20,
        backgroundColor: '#f1f1f1',
        borderRadius: 5,
    },
    navIcon: {
        height: 20,
        width: 20,
        marginHorizontal: 5,
    },
    navText: {
        fontSize: 16,
        fontWeight: 'bold',
    },
});
