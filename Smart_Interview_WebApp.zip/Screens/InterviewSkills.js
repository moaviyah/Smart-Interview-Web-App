import { StyleSheet, Text, View, TouchableOpacity, Image, Dimensions } from 'react-native'
import React from 'react'

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const InterviewSkills = ({ navigation }) => {
    return (
        <View style={styles.container}>
            
            <TouchableOpacity style={styles.goBackContainer} onPress={() => navigation.goBack()}>
                <Image source={require('../assets/back.png')} style={styles.backIcon} />
                <Text style={styles.backTxt}>Go Back</Text>
            </TouchableOpacity>
            <Text>InterviewSkills</Text>
        </View>
    )
}

export default InterviewSkills

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
    },
    goBackContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        width: windowWidth * 0.3
    },
    backIcon: {
        height: 30,
        width: 30,
        marginRight: 5
    },
    backTxt: {
        fontWeight: '700',
        fontSize: 16
    },
})