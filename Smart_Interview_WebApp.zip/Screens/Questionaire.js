import React, { useState, useEffect } from 'react';
import { Text, View, StyleSheet, Image, Dimensions, TouchableOpacity, Alert } from 'react-native';
import { PRIMARY } from '../color';

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const dummyQuestions = [
    {
        question: 'What does HTML stand for?',
        options: [
            'Hyper Text Markup Language',
            'Home Tool Markup Language',
            'Hyperlinks and Text Markup Language',
            'Hyper Tool Markup Language'
        ],
        correctAnswer: 0
    },
    {
        question: 'What does CSS stand for?',
        options: [
            'Computer Style Sheets',
            'Creative Style Sheets',
            'Cascading Style Sheets',
            'Colorful Style Sheets'
        ],
        correctAnswer: 2
    },
    {
        question: 'Which HTML element is used for the largest heading?',
        options: [
            '<heading>',
            '<h1>',
            '<h6>',
            '<head>'
        ],
        correctAnswer: 1
    },
    // {
    //     question: 'Which property is used to change the background color?',
    //     options: [
    //         'background-color',
    //         'color',
    //         'bgcolor',
    //         'background'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'What is the correct HTML element for inserting a line break?',
    //     options: [
    //         '<break>',
    //         '<lb>',
    //         '<br>',
    //         '<linebreak>'
    //     ],
    //     correctAnswer: 2
    // },
    // {
    //     question: 'Which HTML attribute is used to define inline styles?',
    //     options: [
    //         'style',
    //         'styles',
    //         'class',
    //         'font'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'Which CSS property controls the text size?',
    //     options: [
    //         'font-size',
    //         'text-size',
    //         'font-style',
    //         'text-style'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'How do you insert a comment in a CSS file?',
    //     options: [
    //         '// this is a comment',
    //         '/* this is a comment */',
    //         '<!-- this is a comment -->',
    //         '** this is a comment **'
    //     ],
    //     correctAnswer: 1
    // },
    // {
    //     question: 'Which HTML attribute is used to define inline JavaScript?',
    //     options: [
    //         'script',
    //         'js',
    //         'onClick',
    //         'onclick'
    //     ],
    //     correctAnswer: 3
    // },
    // {
    //     question: 'How do you create a function in JavaScript?',
    //     options: [
    //         'function myFunction()',
    //         'function = myFunction()',
    //         'function:myFunction()',
    //         'function => myFunction()'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'How do you call a function named "myFunction"?',
    //     options: [
    //         'call function myFunction()',
    //         'call myFunction()',
    //         'myFunction()',
    //         'myFunction.call()'
    //     ],
    //     correctAnswer: 2
    // },
    // {
    //     question: 'Which operator is used to assign a value to a variable?',
    //     options: [
    //         '*',
    //         'x',
    //         '-',
    //         '='
    //     ],
    //     correctAnswer: 3
    // },
    // {
    //     question: 'What will the following code return: Boolean(10 > 9)?',
    //     options: [
    //         'true',
    //         'false',
    //         'NaN',
    //         'undefined'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'Which HTML tag is used to define an internal style sheet?',
    //     options: [
    //         '<css>',
    //         '<script>',
    //         '<style>',
    //         '<link>'
    //     ],
    //     correctAnswer: 2
    // },
    // {
    //     question: 'Which HTML attribute specifies an alternate text for an image, if the image cannot be displayed?',
    //     options: [
    //         'title',
    //         'src',
    //         'alt',
    //         'longdesc'
    //     ],
    //     correctAnswer: 2
    // },
    // {
    //     question: 'How do you add a background color for all <h1> elements?',
    //     options: [
    //         'h1 {background-color:#FFFFFF;}',
    //         'all.h1 {background-color:#FFFFFF;}',
    //         'h1.all {background-color:#FFFFFF;}',
    //         'h1 {background-color: all#FFFFFF;}'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'Which CSS property is used to change the text color of an element?',
    //     options: [
    //         'text-color',
    //         'fgcolor',
    //         'color',
    //         'font-color'
    //     ],
    //     correctAnswer: 2
    // },
    // {
    //     question: 'What is the correct CSS syntax to make all <p> elements bold?',
    //     options: [
    //         'p {font-weight:bold;}',
    //         'p {text-size:bold;}',
    //         'p {font:bold;}',
    //         'p {font-weight:all-bold;}'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'How do you display hyperlinks without an underline?',
    //     options: [
    //         'a {text-decoration:none;}',
    //         'a {underline:none;}',
    //         'a {decoration:no-underline;}',
    //         'a {text-decoration:no-underline;}'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'How do you make each word in a text start with a capital letter?',
    //     options: [
    //         'text-transform:capitalize',
    //         'text-style:capitalize',
    //         'transform:capitalize',
    //         'You can\'t do that with CSS'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'Which property is used to change the font of an element?',
    //     options: [
    //         'font-family',
    //         'font-style',
    //         'font-weight',
    //         'font'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'How do you make the text bold?',
    //     options: [
    //         'font-weight:bold;',
    //         'style:bold;',
    //         'font:bold;',
    //         'weight:bold;'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'How can you make a list that lists its items with squares?',
    //     options: [
    //         'list-style-type: square;',
    //         'list-type: square;',
    //         'list-square: true;',
    //         'list-style: block;'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'Which property is used to change the left margin of an element?',
    //     options: [
    //         'margin-left',
    //         'padding-left',
    //         'indent',
    //         'left-margin'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'How do you make a list not display bullet points?',
    //     options: [
    //         'list-style-type: none;',
    //         'list-style-type: no-bullets;',
    //         'list: none;',
    //         'list-bullets: none;'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'How do you select an element with id "demo"?',
    //     options: [
    //         '.demo',
    //         '#demo',
    //         'demo',
    //         '*demo'
    //     ],
    //     correctAnswer: 1
    // },
    // {
    //     question: 'How do you select elements with class name "test"?',
    //     options: [
    //         '.test',
    //         '#test',
    //         'test',
    //         '*test'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'What does XML stand for?',
    //     options: [
    //         'eXtensible Markup Language',
    //         'eXecutable Multiple Language',
    //         'eXTra Multi-Program Language',
    //         'eXamine Multiple Language'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'Which HTML attribute is used to define inline styles?',
    //     options: [
    //         'style',
    //         'class',
    //         'font',
    //         'styles'
    //     ],
    //     correctAnswer: 0
    // },
    // {
    //     question: 'Which HTML attribute is used to specify a unique identifier for an element?',
    //     options: [
    //         'class',
    //         'id',
    //         'name',
    //         'style'
    //     ],
    //     correctAnswer: 1
    // }
];

const Questionaire = ({ navigation }) => {
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedOption, setSelectedOption] = useState(null);
    const [answeredQuestions, setAnsweredQuestions] = useState([]);
    const [timer, setTimer] = useState(120);

    useEffect(() => {
        const interval = setInterval(() => {
            setTimer(prevTimer => {
                if (prevTimer === 1) {
                    handleNextQuestion();
                }
                return prevTimer - 1;
            });
        }, 1000);

        return () => clearInterval(interval);
    }, [currentQuestionIndex]);

    const handleOptionSelect = (index) => {
        setSelectedOption(index);
    };

    const handleNextQuestion = () => {
        const updatedAnsweredQuestions = [
            ...answeredQuestions,
            { ...dummyQuestions[currentQuestionIndex], selectedOption }
        ];
        setAnsweredQuestions(updatedAnsweredQuestions);

        if (currentQuestionIndex < dummyQuestions.length - 1) {
            setCurrentQuestionIndex(currentQuestionIndex + 1);
            setSelectedOption(null);
            setTimer(120); // Reset timer for the next question
        } else {
            navigation.navigate('QuizEnd', { answeredQuestions: updatedAnsweredQuestions });
        }
    };

    const currentQuestion = dummyQuestions[currentQuestionIndex];

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Text style={{opacity:0}}></Text>
                <Text style={styles.quesText}>
                    Question {currentQuestionIndex + 1} / {dummyQuestions.length}
                </Text>
                <View style={styles.timerContainer}>
                    <Image source={require('../assets/timer.png')} style={styles.timerIcon} />
                    <Text style={styles.timerText}>{`${Math.floor(timer / 60)}:${timer % 60 < 10 ? '0' : ''}${timer % 60}`}</Text>
                </View>
            </View>
            <Text style={styles.questionText}>{currentQuestion.question}</Text>
            {currentQuestion.options.map((option, index) => (
                <TouchableOpacity
                    key={index}
                    style={[
                        styles.optionContainer,
                        selectedOption === index && styles.selectedOption
                    ]}
                    onPress={() => handleOptionSelect(index)}
                >
                    <Text style={[
                        styles.optionText,
                        selectedOption === index && {color:'white'}
                    ]}>
                        {option}
                    </Text>
                </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.nextButton} onPress={handleNextQuestion}>
                <Text style={styles.nextButtonText}>NEXT</Text>
            </TouchableOpacity>
        </View>
    );
};

export default Questionaire;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    quesText: {
        fontWeight: '700',
        fontSize: 20
    },
    timerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
    },
    timerIcon: {
        height: 30,
        width: 30,
        marginRight: 5,
    },
    timerText: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    questionText: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    optionContainer: {
        padding: 10,
        marginVertical: 5,
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 5,
    },
    selectedOption: {
        backgroundColor: PRIMARY,
    },
    optionText: {
        fontSize: 16,
    },
    nextButton: {
        marginTop: 20,
        padding: 10,
        backgroundColor: PRIMARY,
        borderRadius: 5,
        alignItems: 'center',
    },
    nextButtonText: {
        fontSize: 16,
        color: 'white',
        fontWeight: 'bold',
    },
});
