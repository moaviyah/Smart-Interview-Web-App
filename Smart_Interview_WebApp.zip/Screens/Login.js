import React, { useState, useEffect } from 'react'
import { Text, View, StyleSheet, Dimensions, Image, TouchableOpacity, TextInput, } from 'react-native'
import { PRIMARY } from '../color';

const windowHeight = Dimensions.get('window').height;
const windowWIdth = Dimensions.get('window').width;

const Login = ({ navigation }) => {
    const navigateToCreateAccount =()=>{
        navigation.navigate('CreateAccount')
    }
    return (
        <View style={styles.container}>
            <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', width:windowWIdth*0.07 }} onPress={()=>navigation.goBack()}>
                <Image source={require('../assets/back.png')} style={{ height: 50, width: 50 }} />
                <Text style={{fontWeight: '700',fontSize: 16}}> Go Back </Text>
            </TouchableOpacity>
            <View style={styles.loginContainer}>
                <Text style={styles.welcomeText}>
                    Welcome Back!
                </Text>
                <TouchableOpacity style={styles.googleBtn}>
                    <Image source={require('../assets/google.png')} style={{height:24, width:24}}/>
                    <Text style={styles.googleTxt}>
                        Sign in with google
                    </Text>
                </TouchableOpacity>
                <Text style={styles.signInTxt}>Or, Sign in with email</Text>
                <View style={styles.inputContainer}>
                    <Text style={styles.inputPlaceholders}>
                        Username
                    </Text>
                    <TextInput placeholder='Username' style={styles.input} placeholderTextColor={'#949BA0'}/>
                    <Text style={styles.inputPlaceholders}>
                        Password
                    </Text>
                    <TextInput placeholder='Password' style={styles.input} placeholderTextColor={'#949BA0'}/>
                </View>
                <View style={styles.forgetContainer}>
                    <View style={{flexDirection:'row', alignItems:'center'}}>
                        <Image source={require('../assets/check-box-empty.png')} style={{height:20, width:20}}/>
                        <Text style={{color:PRIMARY, marginLeft:5}}>
                            Remember me
                        </Text>
                    </View>
                    <Text style={{color:'#6543BE', textDecorationLine:'underline'}}>
                        Forget Password?
                    </Text>
                </View>
                <TouchableOpacity style={styles.btn}>
                    <Text style={styles.btnText}>
                        Continue
                    </Text>
                </TouchableOpacity>
                <View style={{flexDirection:'row', alignSelf:'center'}}>
                    <Text style={{color:'#EAAB00'}}>
                        Don't have an account?
                    </Text>
                    <TouchableOpacity style={{color:PRIMARY, textDecorationLine:'underline', marginLeft:5}} onPress={()=>navigateToCreateAccount()}>
                        Register
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    )

}

export default Login;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingHorizontal: windowWIdth * 0.01,
        backgroundColor:'white',
        padding:20
    },
    loginContainer: {
        height: windowHeight * 0.75,
        width: windowWIdth * 0.25,
        backgroundColor: 'white',
        borderRadius:10,
        alignSelf:'center',
        paddingVertical: windowHeight * 0.03,
    },
    welcomeText: {
        fontSize: 24,
        color: PRIMARY,
        alignSelf: 'center',
        fontWeight: '500'
    },
    googleBtn:{
        backgroundColor:'white',
        borderWidth:1,
        borderColor:'#CCC',
        paddingHorizontal:50,
        flexDirection:'row',
        width:windowWIdth*0.15,
        alignSelf:'center',
        paddingVertical:10,
        alignItems:'center',
        justifyContent:'center',
        marginTop:15,
        borderRadius:10
    },
    googleTxt:{
        color:PRIMARY,
        marginLeft:20,
        fontSize:16
    },
    signInTxt:{
        color:'#EAAC00',
        alignSelf:'center',
        marginTop:50,
        fontWeight:'600',
        fontSize:16
    },
    inputContainer:{
        paddingHorizontal:20,
        marginTop:50
    },
    input:{
        borderWidth:0.5,
        borderColor:'#E5E5E5',
        borderRadius:5,
        paddingVertical:10,
        marginBottom:20,
        marginTop:10,
        paddingHorizontal:15,
        
    },
    inputPlaceholders:{
        fontWeight:'600',
        color:PRIMARY,
        fontSize:16
    },
    forgetContainer:{
        flexDirection:'row',
        justifyContent:'space-between',
        paddingHorizontal:20
    },
    btn:{
        backgroundColor:PRIMARY,
        paddingVertical:15,
        marginHorizontal:30,
        borderRadius:10,
        marginVertical:25,
        justifyContent:'center',
        alignItems:'center'
    },
    btnText:{
        color:'white',
        fontWeight:'600',
        fontSize:18
    }
})
