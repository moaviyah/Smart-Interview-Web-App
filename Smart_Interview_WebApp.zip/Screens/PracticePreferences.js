import React, { useState } from 'react';
import { Text, View, StyleSheet, Image, Dimensions, TouchableOpacity, ScrollView } from 'react-native';
import { PRIMARY } from '../color';

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const programmingLanguages = [
    'Java', 'C', 'C++', 'C#', 'Python', 'Swift', 'JavaScript', 'Ruby', 'PHP', 'Go', 'Clojure', 'Haskell'
];

const areasOfExpertise = [
    'Frontend', 'Backend', 'iOS', 'Android', 'Data Science', 'DevOps', 'Management', 'Kernel', 'Security',
    'Machine Learning', 'Big Data', 'Test Automation'
];

const PracticePreferences = ({ navigation }) => {
    const [selectedLanguages, setSelectedLanguages] = useState([]);
    const [selectedExpertise, setSelectedExpertise] = useState([]);

    const toggleSelection = (item, list, setList) => {
        if (list.includes(item)) {
            setList(list.filter(i => i !== item));
        } else {
            setList([...list, item]);
        }
    };

    const renderGridItems = (items, selectedItems, setSelectedItems) => {
        return items.map((item, index) => (
            <TouchableOpacity
                key={index}
                style={[
                    styles.gridItem,
                    { backgroundColor: selectedItems.includes(item) ? '#7F56D9' : '#fff' }
                ]}
                onPress={() => toggleSelection(item, selectedItems, setSelectedItems)}
            >
                <Text style={[
                    styles.gridItemText,
                    { color: selectedItems.includes(item) ? '#fff' : '#000' }
                ]}>{item}</Text>
            </TouchableOpacity>
        ));
    };

    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.goBackContainer} onPress={() => navigation.goBack()}>
                <Image source={require('../assets/back.png')} style={styles.backIcon} />
                <Text style={styles.backTxt}>Go Back</Text>
            </TouchableOpacity>
            <Text style={styles.header}>PRACTICING PREFERENCES</Text>
            <ScrollView contentContainerStyle={styles.formContainer}>
                <Text style={styles.label}>WHAT PROGRAMMING LANGUAGES CAN YOU INTERVIEW IN?</Text>
                <View style={styles.gridContainer}>
                    {renderGridItems(programmingLanguages, selectedLanguages, setSelectedLanguages)}
                </View>

                <Text style={styles.label}>AREAS OF EXPERTISE (CHOOSE ALL THAT APPLY):</Text>
                <View style={styles.gridContainer}>
                    {renderGridItems(areasOfExpertise, selectedExpertise, setSelectedExpertise)}
                </View>
            </ScrollView>

            <View style={styles.navigationContainer}>
                <TouchableOpacity style={styles.navButton} onPress={() => navigation.goBack()}>
                    <Text style={styles.navText}>BACK</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.navButton, {backgroundColor:PRIMARY}]} onPress={()=>navigation.navigate('GetReady')}>
                    <Text style={[styles.navText, { color: 'white' }]}>NEXT</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default PracticePreferences;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
    },
    goBackContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        width: windowWidth * 0.3,
        marginVertical:10
    },
    backIcon: {
        height: 30,
        width: 30,
        marginRight: 5
    },
    backTxt: {
        fontWeight: '700',
        fontSize: 16
    },
    header: {
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        backgroundColor: PRIMARY,
        color: 'white',
        padding: 15,
        marginBottom: 20,
    },
    formContainer: {
        flexGrow: 1,
    },
    label: {
        fontSize: 16,
        fontWeight: 'bold',
        marginVertical: 10,
    },
    gridContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignItems:'center'
    },
    gridItem: {
        width: '30%',
        padding: 15,
        marginVertical: 10,
        alignItems: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#ccc',
        marginHorizontal:10
    },
    gridItemText: {
        fontSize: 14,
        textAlign: 'center',
    },
    navigationContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 20,
        borderTopWidth: 1,
        borderColor: '#ccc',
    },
    navButton: {
        paddingVertical: 10,
        paddingHorizontal: 20,
        backgroundColor: '#f1f1f1',
        borderRadius: 5,
    },
    navText: {
        fontSize: 16,
        fontWeight: 'bold',
    },
});
