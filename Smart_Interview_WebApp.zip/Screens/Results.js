import { StyleSheet, Text, View, ScrollView, Image, Dimensions } from 'react-native';
import React, { useState } from 'react';
import { PRIMARY, SECONDARY, GREEN, RED } from '../color';

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const Results = ({ navigation, route }) => {
    const { answeredQuestions } = route.params;
    console.log('answer length', answeredQuestions.length)
    const [score, setScore] = useState(0)
    console.log(score)
    
    return (
        <View style={styles.container}>
            <Text style={styles.header}>Score  </Text>
            <ScrollView contentContainerStyle={styles.scrollView}>
                {answeredQuestions.map((item, index) => (
                    <View key={index} style={styles.questionContainer}>
                        <Text style={styles.questionText}>{item.question}</Text>
                        {item.options.map((option, optIndex) => {
                            const isCorrect = optIndex === item.correctAnswer;
                            const isSelected = optIndex === item.selectedOption;
                            
                            console.log(isCorrect)
                            return (
                                <View
                                    key={optIndex}
                                    style={[
                                        styles.optionContainer,
                                        isCorrect && styles.correctOption,
                                        isSelected && !isCorrect && styles.incorrectOption
                                    ]}
                                >
                                    <Text
                                        style={[
                                            styles.optionText,
                                            isCorrect && styles.correctOptionText,
                                            isSelected && !isCorrect && styles.incorrectOptionText
                                        ]}
                                    >
                                        {option}
                                    </Text>
                                    {isCorrect && (
                                        <Image
                                            source={require('../assets/check.png')}
                                            style={styles.icon}
                                        />
                                    )}
                                    {isSelected && !isCorrect && (
                                        <Image
                                            source={require('../assets/wrong.png')}
                                            style={styles.icon}
                                        />
                                    )}
                                </View>
                            );
                        })}
                    </View>
                ))}
            </ScrollView>
        </View>
    );
};

export default Results;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        padding: 20,
    },
    header: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        alignSelf: 'center',
        color: PRIMARY
    },
    scrollView: {
        flexGrow: 1,
        paddingBottom: 20,
    },
    questionContainer: {
        marginBottom: 20,
    },
    questionText: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    optionContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
        marginVertical: 5,
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 5,
    },
    correctOption: {
        backgroundColor: 'green',
        borderColor: 'green',
    },
    incorrectOption: {
        backgroundColor: 'red',
        borderColor: 'red',
    },
    optionText: {
        fontSize: 16,
        flex: 1,
    },
    correctOptionText: {
        color: 'white',
    },
    incorrectOptionText: {
        color: 'white',
    },
    icon: {
        width: 20,
        height: 20,
        marginLeft: 10,
    },
});
