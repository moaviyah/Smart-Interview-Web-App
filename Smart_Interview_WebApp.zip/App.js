import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Dimensions } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './Screens/Home';
import Login from './Screens/Login';
import CreateAccount from './Screens/CreateAccount';
import UploadCv from './Screens/TechnicalSkills';
import Background from './Screens/Background';
import PracticePreferences from './Screens/PracticePreferences';
import GetReady from './Screens/GetReady';
import Questionaire from './Screens/Questionaire';
import Results from './Screens/Results';
import QuizEnd from './Screens/QuizEnd';
import FindJobs from './Screens/FindJobs';
import TechnicalSkills from './Screens/TechnicalSkills';
import InterviewSkills from './Screens/InterviewSkills';
import InterviewPreferences from './Screens/InterviewPreferences';
const Stack = createNativeStackNavigator();
const windowHeight = Dimensions.get('window').height;
const windowWIdth = Dimensions.get('window').width;
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name='Login' component={Login} />
        <Stack.Screen name='CreateAccount' component={CreateAccount} />
        <Stack.Screen name='TechnicalSkills' component={TechnicalSkills} />
        <Stack.Screen name='Background' component={Background} />
        <Stack.Screen name='Preferences' component={PracticePreferences} />
        <Stack.Screen name='GetReady' component={GetReady} />
        <Stack.Screen name='Questionaire' component={Questionaire} />
        <Stack.Screen name='Results' component={Results} />
        <Stack.Screen name='QuizEnd' component={QuizEnd} />
        <Stack.Screen name='FindJobs' component={FindJobs} />
        <Stack.Screen name='InterviewPreferences' component={InterviewPreferences} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: windowWIdth * 0.1
  },
});